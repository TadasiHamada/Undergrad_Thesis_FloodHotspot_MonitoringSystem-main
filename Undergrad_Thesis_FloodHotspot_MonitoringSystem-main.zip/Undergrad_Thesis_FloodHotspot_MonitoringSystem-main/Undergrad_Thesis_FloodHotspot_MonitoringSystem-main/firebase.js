// import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.0.2/firebase-app.js';
// import { getAnalytics } from 'https://www.gstatic.com/firebasejs/9.0.2/firebase-analytics.js';


const firebaseConfig = {
    apiKey: "AIzaSyDjNNqbl7J2WLQJpmpc_WWKi59CcukHccw",
    authDomain: "gis-flood-hotspot-monitoring.firebaseapp.com",
    databaseURL: "https://gis-flood-hotspot-monitoring-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "gis-flood-hotspot-monitoring",
    storageBucket: "gis-flood-hotspot-monitoring.appspot.com",
    messagingSenderId: "576566305991",
    appId: "1:576566305991:web:0f6fcd1e0b733a3a738ae2",
    measurementId: "G-G6FEML27RT"
  };

  // Initialize Firebase
  firebaseConfig.initializeApp(firebaseConfig);
  var firebaseRef = firebase.databse().ref("https://gis-flood-hotspot-monitoring-default-rtdb.asia-southeast1.firebasedatabase.app/");
  firebase.on("value" , function(snapshot){
    snapshot.foreach(function(element){
      document.querySelector("#database-panel").innerHTML += `
        <div>${element.val()}</div>
      `
    });
  })

  